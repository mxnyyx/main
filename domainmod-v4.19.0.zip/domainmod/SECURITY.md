[![DomainMOD](https://domainmod.org/images/logo.png)](https://domainmod.org)

Project Home: <https://domainmod.org>  
Project Demo: <https://demo.domainmod.org>  
Documentation: <https://domainmod.org/docs/>  
Source Code: <https://domainmod.org/source/>

# Security Policy

## Reporting a Vulnerability

If you find a vulnerability in DomainMOD, please contact me directly at my personal email address, greg@chetcuti.com. This will ensure the best chance of me seeing your email in a timely manner.
